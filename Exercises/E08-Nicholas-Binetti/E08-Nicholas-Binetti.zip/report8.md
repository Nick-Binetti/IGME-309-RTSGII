# What I learned 
During this exercise I was able to use glPushMatrix() & glPopMatrix in order to make a simple animation for the pendulum while keeping its anchor point in place. 

# Initial Struggles
At first, I had a bit of difficulty trying to draw my circle using the PI constant from the cmath library, but I later found out through a quick Google search that it was because I had forgot to use _USE_MATH_DEFINES at the top of my program. 